const tokenKey = 'chdbchiwebfjcsdcweyifdbihdbchdcjdbckuwe'

module.exports = {
    tokenKey
}